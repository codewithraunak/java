package com.company;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
	// write your code here
        System.out.println("A Simple Calculator");
        System.out.println("Made by [-->Raunak Singh<--]");
        System.out.println("Enter your first number");
        Scanner scan = new Scanner(System.in);
        float a = scan.nextFloat();
        System.out.println("Enter your second no :");
        Scanner scan2 = new Scanner(System.in);
        float b = scan2.nextFloat();
        System.out.println("you have enter");
        System.out.print(a);
        System.out.print(" and ");
        System.out.println(b);
        String prompt = " {" +
                "Enter 0 for addition , 1 for" +
                " Subtraction, 2 for Multiplication, 3 for Division } ";
        System.out.println(prompt);
        System.out.println("Note --> {In Division 1 Number is Numerator and Number 2 is Denominator :) }");
        int input = scan.nextInt();
        switch (input){
            case 0:
                System.out.println("Adding these number");
                System.out.println("the result is: ");
                System.out.print(a + b);
                break;
                case 1:
                System.out.println("Subtracting these number");
                    System.out.print("The result is: ");
                    System.out.println(a-b);
                break;
            case 2:
                System.out.println("Multiplying these number");
                System.out.print("The result is: ");
                System.out.println(a*b);
                break;
            case 3:
                System.out.println("Dividing these number");
                System.out.print("The result is: ");
                System.out.println(a/b);
                break;
            default:
                System.out.println("invalid input");
        }
    }
    }

